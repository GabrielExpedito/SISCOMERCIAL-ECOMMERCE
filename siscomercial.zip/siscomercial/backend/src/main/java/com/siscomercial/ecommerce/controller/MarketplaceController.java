package com.siscomercial.ecommerce.controller;

import com.siscomercial.ecommerce.application.MarketplaceApplicationService;
import com.siscomercial.ecommerce.marketplace.IntegracaoMarketplaceService;
import com.siscomercial.ecommerce.marketplace.MercadoLivreCategoriaService;
import com.siscomercial.ecommerce.model.IntegracaoMarketplace;
import com.siscomercial.ecommerce.model.PublicacaoMarketplace;
import com.siscomercial.ecommerce.model.DTO.MarketplaceDTOs.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * API administrativa RF007. Retorna somente DTOs, nunca tokens ou credenciais.
 */
@RestController
@RequestMapping("/api/retaguarda/marketplaces")
@RequiredArgsConstructor
public class MarketplaceController {
    private final IntegracaoMarketplaceService integracaoService;
    private final MercadoLivreCategoriaService categoriaService;
    private final MarketplaceApplicationService applicationService;

    @GetMapping
    public List<IntegracaoResponse> listar() {
        return integracaoService.listar().stream().map(this::resumo).toList();
    }

    @PostMapping("/mercado-livre")
    public IntegracaoResponse criarMercadoLivre(@RequestBody CriarIntegracaoRequest request) {
        return resumo(integracaoService.criarMercadoLivre(request.lojaProprietaria(), request.identificadorExterno()));
    }

    @PostMapping("/shopee")
    public IntegracaoResponse criarShopee(@RequestBody CriarIntegracaoRequest request) {
        return resumo(integracaoService.criarShopee(request.lojaProprietaria(), request.identificadorExterno()));
    }

    @PostMapping("/amazon")
    public IntegracaoResponse criarAmazon(@RequestBody CriarIntegracaoRequest request) {
        return resumo(integracaoService.criarAmazon(request.lojaProprietaria()));
    }

    @PostMapping("/{id}/shopee/autorizacao")
    public UrlAutorizacaoResponse iniciarAutorizacaoShopee(@PathVariable Long id) {
        return new UrlAutorizacaoResponse(integracaoService.iniciarAutorizacaoShopee(id));
    }

    @GetMapping("/shopee/callback")
    public IntegracaoResponse callbackShopee(@RequestParam String code, @RequestParam("shop_id") String shopId, @RequestParam String state) {
        return resumo(integracaoService.concluirAutorizacaoShopee(code, shopId, state));
    }

    @PostMapping("/{id}/shopee/diagnostico")
    public IntegracaoResponse diagnosticarShopee(@PathVariable Long id) {
        return resumo(integracaoService.diagnosticarShopee(id));
    }

    @PostMapping("/{id}/mercado-livre/autorizacao")
    public UrlAutorizacaoResponse iniciarAutorizacao(@PathVariable Long id) {
        return new UrlAutorizacaoResponse(integracaoService.iniciarAutorizacaoMercadoLivre(id));
    }

    /**
     * Deve corresponder exatamente ao redirect URI registrado na aplicacao Mercado Livre.
     */
    @GetMapping("/mercado-livre/callback")
    public IntegracaoResponse callbackMercadoLivre(@RequestParam String code, @RequestParam String state) {
        return resumo(integracaoService.concluirAutorizacaoMercadoLivre(code, state));
    }

    @PostMapping("/{id}/ativacao")
    public IntegracaoResponse alterarAtivacao(@PathVariable Long id, @RequestBody AlterarAtivacaoRequest request) {
        return resumo(integracaoService.alterarAtivacao(id, request.ativa()));
    }

    @PostMapping("/{id}/diagnostico")
    public IntegracaoResponse diagnosticar(@PathVariable Long id) {
        IntegracaoMarketplace integracao = integracaoService.diagnosticar(id);
        String diagnostico = integracao.getMarketplace() == com.siscomercial.ecommerce.model.Marketplace.AMAZON
                ? "LWA_TOKEN_OK: token obtido; autorização da SP-API Listings e publicação não foram testadas."
                : null;
        return resumo(integracao, diagnostico);
    }

    /**
     * Sugere categorias reais MLB a partir do titulo/nome do produto.
     */
    @GetMapping("/{id}/mercado-livre/categorias")
    public List<MercadoLivreCategoriaService.CategoriaSugestao> preverCategorias(
            @PathVariable Long id,
            @RequestParam String q) {
        return categoriaService.preverCategorias(integracaoService.buscar(id), q);
    }

    /**
     * Retorna a ficha tecnica da categoria selecionada, incluindo atributos required.
     */
    @GetMapping("/{id}/mercado-livre/categorias/{categoryId}/atributos")
    public List<MercadoLivreCategoriaService.AtributoCategoria> listarAtributosCategoria(
            @PathVariable Long id,
            @PathVariable String categoryId) {
        return categoriaService.listarAtributos(integracaoService.buscar(id), categoryId);
    }

    @PostMapping("/publicacoes")
    public PublicacaoResponse publicar(@RequestBody PublicarProdutoRequest request) {
        return publicacao(applicationService.publicarProduto(request.integracaoId(), request.produtoId()));
    }

    @PostMapping("/publicacoes/multicanal")
    public List<PublicacaoResponse> publicarMulticanal(@RequestBody PublicarProdutoMulticanalRequest request) {
        return applicationService.publicarProdutoMulticanal(request.produtoId())
                .stream()
                .map(this::publicacao)
                .toList();
    }

    /**
     * Sincroniza as vendas do marketplace com o estoque local.
     */
    @PostMapping("/{id}/mercado-livre/sincronizar-pedidos")
    public SincronizacaoPedidosResponse sincronizarPedidos(@PathVariable Long id) {
        var resultado = applicationService.sincronizarPedidos(id);
        return new SincronizacaoPedidosResponse(
                resultado.consultados(),
                resultado.processados(),
                resultado.falhas(),
                resultado.sincronizadoEm()
        );
    }

    @GetMapping("/publicacoes")
    public List<PublicacaoResponse> listarPublicacoes(
            @RequestParam(required = false) Long integracaoId) {

        return applicationService.listarPublicacoes(integracaoId)
                .stream()
                .map(this::publicacao)
                .toList();
    }

    @PostMapping("/publicacoes/{publicacaoId}/encerrar")
    public PublicacaoResponse encerrar(
            @PathVariable Long publicacaoId) {

        return publicacao(
                applicationService.encerrarPublicacao(publicacaoId)
        );
    }

    @PostMapping("/publicacoes/{publicacaoId}/sincronizar")
    public PublicacaoResponse sincronizar(
            @PathVariable Long publicacaoId) {

        return publicacao(
                applicationService.sincronizarPublicacao(publicacaoId)
        );
    }

    @PostMapping("/publicacoes/sincronizar")
    public List<PublicacaoResponse> sincronizarTodas(
            @RequestParam(required = false) Long integracaoId) {

        return applicationService.sincronizarPublicacoes(integracaoId)
                .stream()
                .map(this::publicacao)
                .toList();
    }

    private IntegracaoResponse resumo(IntegracaoMarketplace i) {
        return resumo(i, null);
    }

    private IntegracaoResponse resumo(IntegracaoMarketplace i, String diagnostico) {
        return new IntegracaoResponse(i.getId(), i.getLojaProprietaria(), i.getMarketplace(), i.getStatus(),
                i.getIdentificadorExterno(), i.getTokenExpiraEm(), i.getUltimaSincronizacao(), diagnostico);
    }

    private PublicacaoResponse publicacao(PublicacaoMarketplace p) {
        return new PublicacaoResponse(
                p.getId(),
                p.getProduto().getId(),
                p.getIntegracao().getId(),
                p.getIntegracao().getMarketplace(),
                p.getIdentificadorExterno(),
                p.getUrlPublicacao(),
                p.getStatus(),
                p.getQuantidadePublicada(),
                p.getUltimaSincronizacao(),
                p.getUltimoErro(),
                p.getProduto().getNome(),
                p.getProduto().getCodigoInterno(),
                p.getProduto().getImagemPrincipal()
        );
    }
}
